import Login from './Login';

export default {
  routeProps: {
      // path: "/",
      path: "/login",
      element: <Login />
  },
  name: 'Login'
};