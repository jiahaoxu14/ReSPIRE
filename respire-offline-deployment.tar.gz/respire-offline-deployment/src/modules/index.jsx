import LexicalEditor from "./LexicalEditor";
import Login from "./Login";
import Space2Think from "./Space2Think";

export default [
    LexicalEditor,
    // Login,
    Space2Think
];