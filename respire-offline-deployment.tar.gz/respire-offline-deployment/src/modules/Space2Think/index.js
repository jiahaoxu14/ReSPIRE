import Space2Think from './Space2Think';

export default {
  routeProps: {
      // path: "/space2think",
      path: "/",
      element: <Space2Think />
  },
  name: 'Space2Think'
};
