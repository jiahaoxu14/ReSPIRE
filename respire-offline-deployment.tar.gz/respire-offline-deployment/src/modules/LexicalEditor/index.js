import ReportEditor from "./ReportEditor.js";

export default {
  routeProps: {
      path: "/editor",
      element: <ReportEditor />
  },
  name: 'Editor'
};